main() {
    write(1, "hello\n", 6);
}
