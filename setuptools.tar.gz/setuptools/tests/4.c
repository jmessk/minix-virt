main() {
    int a;
    a = 1234;
    printf("a=%d\n", a);
}
