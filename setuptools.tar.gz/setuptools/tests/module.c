
void hello() {
	printf("Hello\n");
}
