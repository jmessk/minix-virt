
main() {
	printf("long = %d\n", sizeof(long));
	printf("short = %d\n", sizeof(short));
	printf("int = %d\n", sizeof(int));
}
