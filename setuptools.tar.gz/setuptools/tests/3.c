main() {
	printf("hello\n");
}
