#ifndef _COMMON_H_
#define _COMMON_H_

#include <iostream>

using namespace std;

typedef unsigned char  uchar;
typedef unsigned short uint16;
typedef signed   short int16;
typedef unsigned int   uint32;

typedef short int16;

#define STDOUT stdout
#define STDERR stderr

#endif
